from typing import Any, Callable, Dict

JWKDict = Dict[str, Any]

HashlibHash = Callable[..., Any]
